#!/bin/bash
#issued on : 17 agustus 2018
#coded By Arvan Apriyana
waktu=$(date '+%Y-%m-%d %H:%M:%S')
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
LIGHTGREEN="\e[92m"
MARGENTA="\e[35m"
BLUE="\e[34m"
BOLD="\e[1m"
NOCOLOR="\e[0m"
header(){
printf "${GREEN}
         ####################################
         ####################################
         #######                      #######
         #######                      #######
         #######                      #######
         ###############      ###############
         ###############      ###############
         ###############      ###############
         ###############      ###############${RED}
         #######    ####      ####    #######
         #######    ####      ####    #######
         #######    ##############    #######
         #######    ##############    #######
         #######                      #######
         ####################################
         ####################################s${NOCOLOR}
         ------------------------------------
             Auto Delete Friend Facebook
               Code By: Arvan Apriyana
                 www.tatsumi-crew.net
         ------------------------------------
"
}
tatsumi(){
    tokenfb="$1"
    jumlahdel="$2"
    curlnya=$(curl -s "http://48.nakocoders.org/api/deletefriend/curl.php?tokenna=$1&jumlahna=$2" -L)
    status=$(echo $curlnya | grep -Po '(?<=green"> )[^<]*')
    kontenID=$(echo $curlnya | grep -Po '(?<=Success Delete : )[^<span]*')
	printf "${GREEN}$kontenID => ${GREEN}$status\n"
}
header
echo "Method : "
echo "1. Delete Friends"
read -p "Choose Your Method : " method;

if [ $method -eq 1 ]; then
	read -p "Masukan Token FB : " tokenfb;
	read -p "Masukan Jumlah Delete : " jumlahdel;
	for pwna in $tokenfb; do
		tatsumi $pwna $jumlahdel
done
fi
