#!/bin/bash
#issued on : 17 agustus 2018
#coded By Arvan Apriyana
waktu=$(date '+%Y-%m-%d %H:%M:%S')
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
LIGHTGREEN="\e[92m"
MARGENTA="\e[35m"
BLUE="\e[34m"
BOLD="\e[1m"
NOCOLOR="\e[0m"
header(){
printf "${GREEN}
         ####################################
         ####################################
         #######                      #######
         #######                      #######
         #######                      #######
         ###############      ###############
         ###############      ###############
         ###############      ###############
         ###############      ###############${RED}
         #######    ####      ####    #######
         #######    ####      ####    #######
         #######    ##############    #######
         #######    ##############    #######
         #######                      #######
         ####################################
         ####################################${NOCOLOR}
         ------------------------------------
              Bot Reaction Facebook V.1 
        LOVE | LIKE | HAHA | WOW | SAD | ANGRY
               Code By: Arvan Apriyana
                 www.tatsumi-crew.net
         ------------------------------------
"
}
tatsumi(){
    typena="$1"
    tokenfb="$2"
    jumlahna="$3"
    curlnya=$(curl -s "http://48.nakocoders.org/api/reaction/api.php?type=$1&tokenna=$2&jumlah=$3" -L)
    kontenID=$(echo $curlnya | grep -Po '(?<=Success Like : )[^<span]*')
    printf "${GREEN}$kontenID\n"
}
header
echo "Method : "
echo "1. Delete Friends"
read -p "Choose Your Method : " method;

if [ $method -eq 1 ]; then
    read -p "Masukan Type Reaction : " typena;
    read -p "Masukan Token FB : " tokenfb;
    read -p "Masukan Jumlah Like : " jumlahna;
    for pwna in $typena; do
        tatsumi $pwna $tokenfb
done
fi
